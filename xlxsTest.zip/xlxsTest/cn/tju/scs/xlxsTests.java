package cn.tju.scs;

import java.util.regex.Pattern;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.DateUtil;  
import org.apache.poi.ss.usermodel.Row; 
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class xlxsTests {
	private WebDriver driver;
	  private String baseUrl;
	  private String weburl;
	  private String id;
	  //private String cellValue;
	  private String cellValue1;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();
	  private static final String EXCEL_XLS = "xls";  
	    private static final String EXCEL_XLSX = "xlsx";  
	 
	    public static Workbook getWorkbok(InputStream in,File file) throws IOException{  
	        Workbook wb = null;  
	        if(file.getName().endsWith(EXCEL_XLS)){  //Excel 2003  
	            wb = new HSSFWorkbook(in);  
	        }else if(file.getName().endsWith(EXCEL_XLSX)){  // Excel 2007/2010  
	            wb = new XSSFWorkbook(in);  
	        }  
	        return wb;  
	    }  

public static void checkExcelVaild(File file) throws Exception{  
    if(!file.exists()){  
        throw new Exception("�ļ�������");  
    }  
}

@Before
public void setUp() throws Exception {
	System.setProperty ( "webdriver.firefox.bin" , "D:/���������/firefox.exe" );
 // WebDriver driver = new FirefoxDriver();
	driver = new FirefoxDriver();
  baseUrl = "https://psych.liebes.top";
  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  driver.get(baseUrl + "/st");
}


@Test
public void testLab2() throws Exception {
	File excelFile = new File("D:/���������/input.xlsx"); // �����ļ�����  
    FileInputStream is = new FileInputStream(excelFile); // �ļ���  
    checkExcelVaild(excelFile);  
    Workbook workbook = getWorkbok(is,excelFile);  
    int sheetCount = workbook.getNumberOfSheets();
    Sheet sheet = workbook.getSheetAt(0);
    for (Row row : sheet) { 
    	if(row.getCell(0).toString().equals("")){  
            return ;  
        }  
        //String rowValue = "";  
        for (Cell cell : row) {  
            if(cell.toString() == null){  
                continue;  
            }  
            
			int cellType = cell.getCellType();  
            //String cellValue = "";  
           /* switch (cellType) {  
            case Cell.CELL_TYPE_STRING:     // �ı�  
                weburl = cell.getRichStringCellValue().getString() ;  
                break;  
            case Cell.CELL_TYPE_NUMERIC:
            	cell.setCellType(Cell.CELL_TYPE_STRING);  
                cellValue1 = String.valueOf(cell.getRichStringCellValue().getString()) ;
                id=cellValue1.substring(4);
                break;
            case Cell.CELL_TYPE_BLANK: // �հ�  
                weburl = cell.getStringCellValue();  
                break;  
            }*/
			if(cellType==Cell.CELL_TYPE_STRING)
				 weburl = cell.getRichStringCellValue().getString() ; 
			else if(cellType==Cell.CELL_TYPE_NUMERIC){
				cellValue1 = String.valueOf(cell.getRichStringCellValue().getString()) ;
                id=cellValue1.substring(4);
			}
            else if(cellType==Cell.CELL_TYPE_BLANK)
            	weburl = cell.getStringCellValue();  
			}
        
 //driver.get(baseUrl + "/st");
  driver.findElement(By.id("username")).clear();
  driver.findElement(By.id("username")).sendKeys(cellValue1);
  driver.findElement(By.id("password")).clear();
  driver.findElement(By.id("password")).sendKeys(id);
  driver.findElement(By.id("submitButton")).click();
  assertEquals(weburl,driver.findElement(By.xpath("html/body/div[1]/div[2]")).getText());
}
    }



        @After
        public void tearDown() throws Exception {
           String verificationErrorString = verificationErrors.toString();
          if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
          }
        }

        private boolean isElementPresent(By by) {
          try {
            driver.findElement(by);
            return true;
          } catch (NoSuchElementException e) {
            return false;
          }
        }

        private boolean isAlertPresent() {
          try {
            driver.switchTo().alert();
            return true;
          } catch (NoAlertPresentException e) {
            return false;
          }
        }

        private String closeAlertAndGetItsText() {
          try {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert) {
              alert.accept();
            } else {
              alert.dismiss();
            }
            return alertText;
          } finally {
            acceptNextAlert = true;
          }
        }
    }